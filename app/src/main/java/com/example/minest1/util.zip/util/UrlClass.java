package com.example.minest1.util;
public class UrlClass {
    private  static  String BASE_URL = "http://192.168.1.5:80000";

    public static String PREDICT_URL = BASE_URL + "/predict";
    public static String FILE_TEST_URL = BASE_URL + "/files";
}
