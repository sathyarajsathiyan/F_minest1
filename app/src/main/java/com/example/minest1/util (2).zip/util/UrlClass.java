package com.example.minest1.util;
public class UrlClass {
    private  static  String BASE_URL = "http://192.168.1.4:80000";

    public static String PREDICT_URL = "http://192.168.1.4:8000/predict";
    public static String FILE_TEST_URL = BASE_URL + "/files";

    public static String IMAGE_BASE_URL = "http://192.168.1.4:4000/";
}
